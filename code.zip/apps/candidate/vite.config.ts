import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
export default defineConfig({
  envDir: "../..",
  plugins: [react(), tailwindcss()],
  server: { host: "0.0.0.0", port: 5175, proxy: { "/api": "http://localhost:3000", "/chain": "http://localhost:3000" } },
  build: { outDir: "dist", emptyOutDir: true, sourcemap: true }
});
