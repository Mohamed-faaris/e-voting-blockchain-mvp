import React,{useEffect,useState}from"react";import{lazy,Suspense}from"react";import{Activity,Boxes,Compass,FileCheck,Fingerprint,GitFork,Lock,Search,Users,Vote,LayoutDashboard,Network}from"lucide-react";import{WorkspaceShell,type NavItem}from"@evoting/ui";
const HomePage=lazy(()=>import("./pages/HomePage").then(m=>({default:m.HomePage})));
const SystemCheckPage=lazy(()=>import("./pages/SystemCheckPage").then(m=>({default:m.SystemCheckPage})));
const CandidatePage=lazy(()=>import("./pages/CandidatePage").then(m=>({default:m.CandidatePage})));
const AdminPage=lazy(()=>import("./pages/AdminPage").then(m=>({default:m.AdminPage})));
const ExplanationPage=lazy(()=>import("./pages/ExplanationPage").then(m=>({default:m.ExplanationPage})));
const MerkleTreePage=lazy(()=>import("./pages/MerkleTreePage").then(m=>({default:m.MerkleTreePage})));
const BlockExplorerPage=lazy(()=>import("./pages/BlockExplorerPage").then(m=>({default:m.BlockExplorerPage})));
const VoterCheckinPage=lazy(()=>import("./pages/VoterCheckinPage").then(m=>({default:m.VoterCheckinPage})));
const BallotCastingPage=lazy(()=>import("./pages/BallotCastingPage").then(m=>({default:m.BallotCastingPage})));
const BallotReceiptPage=lazy(()=>import("./pages/BallotReceiptPage").then(m=>({default:m.BallotReceiptPage})));
const ReceiptVerifier=lazy(()=>import("./components/ReceiptVerifier").then(m=>({default:m.ReceiptVerifier})));
const routes=["home","booth","booth-checkin","booth-ballot","booth-receipt","candidate","admin","system-check","explanation","merkle-tree","blocks","verifier"];
const portals=[["Voter",import.meta.env.VITE_VOTER_URL||"http://localhost:5174"],["Candidate",import.meta.env.VITE_CANDIDATE_URL||"http://localhost:5175"],["Explorer",import.meta.env.VITE_EXPLORER_URL||"http://localhost:5176"]];
const nav:NavItem[]=[{label:"Overview",path:"home",icon:LayoutDashboard,group:"Workspace"},{label:"Voter check-in",path:"booth-checkin",icon:Fingerprint,group:"Voting workflow"},{label:"Secret ballot",path:"booth-ballot",icon:Vote,group:"Voting workflow"},{label:"Vote receipt",path:"booth-receipt",icon:FileCheck,group:"Voting workflow"},{label:"Candidate oversight",path:"candidate",icon:Users,group:"Oversight"},{label:"Administration",path:"admin",icon:Lock,group:"Oversight"},{label:"System diagnostics",path:"system-check",icon:Activity,group:"Infrastructure"},{label:"Block explorer",path:"blocks",icon:Boxes,group:"Ledger & proofs"},{label:"Merkle tree",path:"merkle-tree",icon:GitFork,group:"Ledger & proofs"},{label:"Receipt verifier",path:"verifier",icon:Search,group:"Ledger & proofs"},{label:"Protocol guide",path:"explanation",icon:Compass,group:"Ledger & proofs"}];
export function App(){const route=()=>{const value=window.location.hash.replace(/^#\/?/,"");return routes.includes(value)?value:"home";};const[currentRoute,setCurrentRoute]=useState(route);const[activeToken,setActiveToken]=useState<{tokenId:string;publicKey:string;privateKey:string;districtId:string;voterName:string}|null>(null);const[lastReceipt,setLastReceipt]=useState<any>(null);const[notification,setNotification]=useState<{message:string;type:"ok"|"err"}|null>(null);
useEffect(()=>{const onChange=()=>setCurrentRoute(route());window.addEventListener("hashchange",onChange);return()=>window.removeEventListener("hashchange",onChange);},[]);
const navigate=(path:string)=>{window.location.hash=`#/${path}`;setCurrentRoute(path);};const notify=(message:string,type:"ok"|"err")=>{setNotification({message,type});window.setTimeout(()=>setNotification(null),6000);};
return <WorkspaceShell brand="Civic Ledger" tagline="Election command center" activePath={currentRoute==="booth"?"booth-checkin":currentRoute} navItems={nav} onNavigate={navigate} notice={notification} onDismissNotice={()=>setNotification(null)} topbarExtra={<><div className="ev-row">{portals.map(([label,url])=><a key={label} href={url} className="ev-button secondary">{label}</a>)}</div><span style={{color:"var(--ev-muted)",fontSize:11,display:"flex",alignItems:"center",gap:6}}><Network size={14}/> API workspace</span></>}>
<Suspense fallback={<div className="ev-empty" role="status">Loading workspace module…</div>}>
{currentRoute==="home"&&<HomePage onNavigate={navigate}/>}
{(currentRoute==="booth-checkin"||currentRoute==="booth")&&<VoterCheckinPage onTokenIssued={token=>{setActiveToken(token);notify(`Demo token issued for ${token.voterName}. Ready for ballot selection.`,"ok");}} onNavigate={navigate}/>}
{currentRoute==="booth-ballot"&&<BallotCastingPage tokenData={activeToken} onVoteCast={receipt=>{setLastReceipt(receipt);setActiveToken(null);notify(`Ballot appended to demo block #${receipt.blockIndex}.`,"ok");}} onNavigate={navigate}/>}
{currentRoute==="booth-receipt"&&<BallotReceiptPage receipt={lastReceipt} onNavigate={navigate} onResetSession={()=>{setActiveToken(null);setLastReceipt(null);}}/>}
{currentRoute==="candidate"&&<CandidatePage/>}{currentRoute==="admin"&&<AdminPage/>}{currentRoute==="system-check"&&<SystemCheckPage/>}{currentRoute==="explanation"&&<ExplanationPage/>}{currentRoute==="merkle-tree"&&<MerkleTreePage/>}{currentRoute==="blocks"&&<BlockExplorerPage/>}{currentRoute==="verifier"&&<ReceiptVerifier/>}
</Suspense>
</WorkspaceShell>;
}
